import React from 'react';
import {
  ActivityIndicator,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { AlertCircle, Check, Cloud, CloudOff } from 'lucide-react-native';
import { Colors } from '@/src/constants/colors';
import { useAuth } from '@/src/context/AuthContext';
import { useSync } from '@/src/context/SyncContext';
import { UserAccountModal } from './UserAccountModal';

export function SyncStatusChip() {
  const { user, signIn, isGuestMode, loading, error: authError } = useAuth();
  const { status, lastSyncAt, sync, syncError } = useSync();

  if (!user) {
    const showAuthError = !!authError;
    return (
      <TouchableOpacity
        style={[styles.chip, showAuthError && styles.chipError]}
        onPress={signIn}
        disabled={loading}
      >
        <CloudOff color={Colors.textMuted} size={12} strokeWidth={1.8} />
        <Text style={[styles.muted, showAuthError && styles.errorText]} numberOfLines={1}>
          {loading ? 'Đang đăng nhập...' : showAuthError ? 'Lỗi đăng nhập' : isGuestMode ? 'Khách' : 'Đăng nhập'}
        </Text>
      </TouchableOpacity>
    );
  }

  let icon: React.ReactNode;
  let label = '';
  let errorBorder = false;

  switch (status) {
    case 'syncing':
      icon = <ActivityIndicator size={12} color={Colors.accent} />;
      label = 'Đang đồng bộ...';
      break;
    case 'synced':
      icon = <Check color={Colors.success} size={12} strokeWidth={2} />;
      label = lastSyncAt
        ? lastSyncAt.toLocaleTimeString('vi-VN', {
            hour: '2-digit',
            minute: '2-digit',
          })
        : 'Đã đồng bộ';
      break;
    case 'error':
      icon = <AlertCircle color={Colors.error} size={12} strokeWidth={1.8} />;
      label = syncError || 'Lỗi đồng bộ';
      errorBorder = true;
      break;
    default:
      icon = <Cloud color={Colors.textMuted} size={12} strokeWidth={1.8} />;
      label = user.email?.split('@')[0] ?? 'Đã đăng nhập';
  }

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={[styles.chip, errorBorder && styles.chipError]}
        onPress={sync}
      >
        {icon}
        <Text style={[styles.label, errorBorder && styles.errorText]} numberOfLines={1}>
          {label}
        </Text>
      </TouchableOpacity>
      <UserAccountModal />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 20,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.border,
    maxWidth: 160,
  },
  chipError: {
    borderColor: Colors.error,
  },
  label: {
    fontSize: 11,
    color: Colors.textSecondary,
    fontWeight: '500',
  },
  muted: {
    fontSize: 11,
    color: Colors.textMuted,
    fontWeight: '500',
  },
  errorText: {
    color: Colors.error,
  },
});
